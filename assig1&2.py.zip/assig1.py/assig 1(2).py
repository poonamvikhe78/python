# celsius to fahrenheit

celsius = float(input("Enter temperature in celsius: "))
fahrenheit = (celsius * 1.8) + 32
print('%.2f celsius is: %0.2f fahrenheit' %(celsius, fahrenheit))

fahrenheit = float(input("Enter temperature in fahrenheit: "))
celsius = (fahrenheit - 32) * 5/9
print('%.2f Fahrenheit is: %0.2f Celsius' %(fahrenheit, celsius))