# Reading length from user

length = float (input("Enter length of the rectangle: "))
breadth = float (input("Enter breath of the rectangle: "))

area = length * breadth

perimeter = 2 * (length * breadth)

print("Area of rectangle =", area)
print("perimeter of rectangle = ", perimeter)