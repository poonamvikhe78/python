def compound_intrest(principal,rate,time):
    amount = principal * (pow((1 + rate / 100), time))
    CI = amount - principal
    print("compound intrest is", CI)

    compound_intrest(100, 10, 5)
    