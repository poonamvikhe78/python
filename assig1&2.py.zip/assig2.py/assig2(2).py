# Python program to find the largest number
# among the three numbers using library function
def maximum(a, b, c):
    list = [a, b, c]
    list.sort()
    return list[-1]


# Driven code
a = 10
b = 14
c = 12
print(maximum(a, b, c))


