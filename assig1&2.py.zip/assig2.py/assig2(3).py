num = float(input("Input a number: "))
if (num > 0):
 print("It is a positive number")
elif(num==0):
  print("It is zero")
else:
 print("It is a negative number")
