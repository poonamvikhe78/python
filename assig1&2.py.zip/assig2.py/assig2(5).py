calls = int(input("enter number of call: "))

if calls <= 100:
    bill = 200
elif calls > 100 and calls <= 150:
    calls = calls - 100
    bill = 200 + (0.60 * calls)
elif calls > 150 and calls <= 200:
    calls = calls - 150
    bill = 200 + (0.60 * 50) + (0.50 * calls)
else:
    calls = calls -200
    bill = 200 + (0.60 * 50) + (0.50 * 50) + (0.40 * calls)

print("total bill amount is", bill)