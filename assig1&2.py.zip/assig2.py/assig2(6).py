sub1 = int(input("enter marks obtain in subject 1: "))
sub2 = int(input("enter marks obtain in subject 2: "))
sub3 = int(input("enter marks obtain in subject 3: "))

avg_marks = (sub1 + sub2 + sub3) / 3
print("average marks:", format(avg_marks,'.2f'))

if avg_marks >= 90:
    print("grade: A")
elif avg_marks >= 80:
    print("grade: B")
elif avg_marks >= 70:
    print("grade: C")
elif avg_marks >= 60:
    print("grade: D")
else:
    print("grade: F")