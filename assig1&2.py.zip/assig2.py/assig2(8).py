letter = input("Enter a letter: ")
if letter == 'a' or letter == 'e' or letter == 'i' or letter == 'o' or letter == 'u':
    print(letter, "is a vowel.")
else:
    print(letter, "is a consonant.")

