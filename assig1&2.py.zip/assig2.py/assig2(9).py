def simple_interest(p,t,r):

 si = (p * t * r)/100
 print('The Simple Interest is', si)

 return si

 a=int(input('the principal') )
 b=int(input('the time period'))
 c=int(input('the rate of interest'))
 simple_interest(a,b,c)








